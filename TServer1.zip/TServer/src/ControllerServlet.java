
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import PlanetRenox.AES256_GCM;

@WebServlet
public class ControllerServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		String mainPageOr = request.getParameter("path");
		System.out.println(mainPageOr);
		// Correct Path in Address Bar
		if (mainPageOr == null)
		{
			String dirPath = request.getRequestURI().substring(9);

			response.setContentType("text/html");
			PrintWriter out = response.getWriter();

			out.println("<!DOCTYPE html>\r\n" + "<html lang=\"en\" dir=\"ltr\">\r\n" + "\r\n" + "<head>\r\n"
					+ "  <meta charset=\"utf-8\">\r\n" + "  <title>plan</title>\r\n" + "\r\n" + "  <style>\r\n"
					+ "    body {\r\n" + "      background-color: powderblue;\r\n" + "    }\r\n" + "\r\n"
					+ "    p {\r\n" + "      text-align: center;\r\n" + "      font-size: 25px;\r\n" + "    }\r\n"
					+ "\r\n" + "    textarea {\r\n" + "      margin: 20px;\r\n" + "    }\r\n" + "  </style>\r\n"
					+ "\r\n" + "</head>\r\n" + "\r\n" + "<body>\r\n" + "  <p>\r\n" + "    Your site\r\n" + "  </p>\r\n"
					+ "\r\n" + "  <form method='post' action='ControllerServlet' >\r\n"
					+ "    <textarea name=\"textcontent\" rows=\"50%\" cols=\"230%\">\r\n" + "</textarea>\r\n" + "\r\n"
					+ "    <input type=\"password\" name=\"pass\" />\r\n" + "\r\n"
					+ "    <input type=\"hidden\" name=\"path\" value=\"" + dirPath + "\" />\r\n" + "\r\n"
					+ "    <p>\r\n" + "      <input value='Enter' type='submit' />\r\n" + "    </p>\r\n"
					+ "  </form>\r\n"
					+ "  <iframe name=\"hiddenFrame\" width=\"0\" height=\"0\" border=\"0\" style=\"display: none;\"></iframe>\r\n"
					+ "\r\n" + "</body>\r\n" + "\r\n" + "</html>");

			out.close();
		}
		else
		{
			response.sendRedirect(mainPageOr);
		}

	}

	public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException
	{
		
		

		if (request.getRequestURI().substring(9).equals("ControllerServlet"))
		{
			response.setStatus(307);
			response.setHeader("Location", request.getParameter("path"));
			return;
		}

		ServletContext context = request.getServletContext();
		String warPath = context.getRealPath("/");
		System.out.println(warPath);
		File file = new File(warPath + "WEB-INF\\pages\\" + request.getRequestURI().substring(9));

		if (request.getParameter("textcontent") == null) //if null = frontpage ? text page
		{
			if (file.isFile()) // if file exists decrypt, if not, dont
			{
				Path path = Paths.get(warPath + "WEB-INF\\pages\\" + request.getRequestURI().substring(9));
				byte[] data = Files.readAllBytes(path);

				response.setContentType("text/html");
				PrintWriter out = response.getWriter();

				out.println("<!DOCTYPE html>\r\n" + "<html lang=\"en\" dir=\"ltr\">\r\n" + "\r\n" + "<head>\r\n"
						+ "  <meta charset=\"utf-8\">\r\n" + "  <title>plan</title>\r\n" + "\r\n" + "  <style>\r\n"
						+ "    body {\r\n" + "      background-color: powderblue;\r\n" + "    }\r\n" + "\r\n"
						+ "    p {\r\n" + "      text-align: center;\r\n" + "      font-size: 25px;\r\n" + "    }\r\n"
						+ "\r\n" + "    textarea {\r\n" + "      margin: 20px;\r\n" + "    }\r\n" + "  </style>\r\n"
						+ "\r\n" + "</head>\r\n" + "\r\n" + "<body>\r\n" + "  <p>\r\n" + "    " + request.getParameter("path") + "\r\n"
						+ "  </p>\r\n" + "\r\n" + "  <form method='post' action='ControllerServlet'>\r\n"
						+ "    <textarea name=\"textcontent\" rows=\"50%\" cols=\"230%\" >\r\n"
						+ AES256_GCM.decrypt(data, request.getParameter("pass")) + "</textarea>\r\n" + "\r\n"
						+ "    <input type=\"hidden\" name=\"path\" value=\"" + request.getParameter("path")
						+ "\" />\r\n" + "    <input type=\"hidden\" name=\"pass\" value=\""
						+ request.getParameter("pass") + "\" />\r\n" + "\r\n" + "    <p>\r\n"
						+ "      <input value='Enter' type='submit' />\r\n" + "    </p>\r\n" + "  </form>\r\n" + "\r\n"
						+ "</body>\r\n" + "\r\n" + "</html>");

				out.close();

			}
			else // file doesnt exist, create a new text page for user
			{
				response.setContentType("text/html");
				PrintWriter out = response.getWriter();

				out.println("<!DOCTYPE html>\r\n" + "<html lang=\"en\" dir=\"ltr\">\r\n" + "\r\n" + "<head>\r\n"
						+ "  <meta charset=\"utf-8\">\r\n" + "  <title>plan</title>\r\n" + "\r\n" + "  <style>\r\n"
						+ "    body {\r\n" + "      background-color: powderblue;\r\n" + "    }\r\n" + "\r\n"
						+ "    p {\r\n" + "      text-align: center;\r\n" + "      font-size: 25px;\r\n" + "    }\r\n"
						+ "\r\n" + "    textarea {\r\n" + "      margin: 20px;\r\n" + "    }\r\n" + "  </style>\r\n"
						+ "\r\n" + "</head>\r\n" + "\r\n" + "<body>\r\n" + "  <p>\r\n" + "    create new site\r\n"
						+ "  </p>\r\n" + "\r\n" + "  <form method='post' action='ControllerServlet'>\r\n"
						+ "    <textarea name=\"textcontent\" rows=\"50%\" cols=\"230%\">\r\n" + "</textarea>\r\n"
						+ "\r\n" + "    <input type=\"hidden\" name=\"path\" value=\"" + request.getParameter("path")
						+ "\" />\r\n" + "    <input type=\"hidden\" name=\"pass\" value=\""
						+ request.getParameter("pass") + "\" />\r\n" + "\r\n" + "    <p>\r\n"
						+ "      <input value='Enter' type='submit' />\r\n" + "    </p>\r\n" + "  </form>\r\n" + "\r\n"
						+ "</body>\r\n" + "\r\n" + "</html>");

				out.close();
			}

		}
		else // user is trying to save new text
		{

			BufferedOutputStream writeBuffer = null;
			PrintWriter out = null;
			try
			{
				writeBuffer = new BufferedOutputStream(new FileOutputStream(file));
				writeBuffer
						.write(AES256_GCM.encrypt(request.getParameter("textcontent"), request.getParameter("pass")));

				response.setContentType("text/html");
				out = response.getWriter();

				out.println("<!DOCTYPE html>\r\n" + "<html lang=\"en\" dir=\"ltr\">\r\n" + "\r\n" + "<head>\r\n"
						+ "  <meta charset=\"utf-8\">\r\n" + "  <title>plan</title>\r\n" + "\r\n" + "  <style>\r\n"
						+ "    body {\r\n" + "      background-color: powderblue;\r\n" + "    }\r\n" + "\r\n"
						+ "    p {\r\n" + "      text-align: center;\r\n" + "      font-size: 25px;\r\n" + "    }\r\n"
						+ "\r\n" + "    textarea {\r\n" + "      margin: 20px;\r\n" + "    }\r\n" + "  </style>\r\n"
						+ "\r\n" + "</head>\r\n" + "\r\n" + "<body>\r\n" + "  <p>\r\n" + "    create new site\r\n"
						+ "  </p>\r\n" + "\r\n" + "  <form method='post' action='ControllerServlet'>\r\n"
						+ "    <textarea name=\"textcontent\" rows=\"50%\" cols=\"230%\" >\r\n"
						+ request.getParameter("textcontent") + "</textarea>\r\n" + "\r\n"
						+ "    <input type=\"hidden\" name=\"path\" value=\"" + request.getParameter("path")
						+ "\" />\r\n" + "    <input type=\"hidden\" name=\"pass\" value=\""
						+ request.getParameter("pass") + "\" />\r\n" + "\r\n" + "    <p>\r\n"
						+ "      <input value='Enter' type='submit' />\r\n" + "    </p>\r\n" + "  </form>\r\n" + "\r\n"
						+ "</body>\r\n" + "\r\n" + "</html>");

			}
			finally
			{
				out.close();
				writeBuffer.close();
			}
		}

	}

}
